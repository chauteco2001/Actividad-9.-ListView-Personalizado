package com.example.actividad9_4figuras;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class PentagonoActivity extends AppCompatActivity {

    private EditText etLado;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pentagono);

        etLado = findViewById(R.id.etLado);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcularArea = findViewById(R.id.btnCalcularArea);
        Button btnCalcularPerimetro = findViewById(R.id.btnCalcularPerimetro);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnCalcularArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularArea();
            }
        });

        btnCalcularPerimetro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPerimetro();
            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra esta actividad y regresa a la actividad anterior
            }
        });
    }

    private void calcularArea() {
        // Obtener el valor del lado del EditText
        String ladoStr = etLado.getText().toString().trim();

        if (!ladoStr.isEmpty()) {
            // Convertir el valor del lado a un número
            double lado = Double.parseDouble(ladoStr);

            // Calcular el área usando la fórmula del pentágono
            double area = (5 * lado * lado) / (4 * Math.tan(Math.PI / 5));

            // Redondear el resultado a dos decimales
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String resultado = "Área del pentágono: " + decimalFormat.format(area);

            ImageView ivPentagono = findViewById(R.id.ivPentagono);
            ivPentagono.setVisibility(View.VISIBLE);

            // Mostrar el resultado en el TextView
            tvResultado.setText(resultado);


        } else {
            // Manejar el caso en el que el campo del lado esté vacío
            tvResultado.setText("Por favor, introduce el lado del pentágono.");

            ImageView ivPentagono = findViewById(R.id.ivPentagono);
            ivPentagono.setVisibility(View.GONE);
        }
    }


    private void calcularPerimetro() {
        String ladoStr = etLado.getText().toString().trim();

        if (!ladoStr.isEmpty()) {
            double lado = Double.parseDouble(ladoStr);
            double perimetro = 5 * lado;

            // Redondear el resultado a dos decimales
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String resultado = "Perímetro del pentágono: " + decimalFormat.format(perimetro);

            ImageView ivPentagono = findViewById(R.id.ivPentagono);
            ivPentagono.setVisibility(View.VISIBLE);

            tvResultado.setText(resultado);
        } else {
            tvResultado.setText("Por favor, introduce el lado del pentágono.");

            ImageView ivPentagono = findViewById(R.id.ivPentagono);
            ivPentagono.setVisibility(View.GONE);
        }
    }
}