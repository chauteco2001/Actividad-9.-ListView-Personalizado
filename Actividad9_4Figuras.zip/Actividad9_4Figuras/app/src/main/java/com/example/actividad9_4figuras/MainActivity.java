package com.example.actividad9_4figuras;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        String[] areas = {"(perimetro*apotema)/2", "(perimetro*apotema)/2", "6*a^2", "b*h /2"};
        String[] perimetros = {"lado * 6", "lado * 5", "a^3", " lado * 3"};
        int[] imageIds = {R.drawable.hexagono, R.drawable.pentagono, R.drawable.cubo, R.drawable.triangulo_equilatero};

        listView = findViewById(R.id.listView);


        CustomListAdapter adapter = new CustomListAdapter(this, areas, perimetros, imageIds);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent intent1 = new Intent(MainActivity.this, HexagonoActivity.class);
                        startActivity(intent1);
                        break;
                    case 1:
                        Intent intent2 = new Intent(MainActivity.this, PentagonoActivity.class);
                        startActivity(intent2);
                        break;

                    case 2:
                        Intent intent3 = new Intent(MainActivity.this, PentagonoActivity.class);
                        startActivity(intent3);
                        break;


                    case 3:
                        Intent intent4 = new Intent(MainActivity.this, Triangulo_equilateroActivity.class);
                        startActivity(intent4);
                        break;


                    case 4 :
                        Intent intent5 = new Intent(MainActivity.this, Triangulo_equilateroActivity.class);
                        startActivity(intent5);
                        break;

                    default:
                        break;
                }
            }
        });
    }
}