package com.example.actividad9_4figuras;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class CuboActivity extends AppCompatActivity {

    private EditText etLado;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cubo);

        etLado = findViewById(R.id.etLado);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcularArea = findViewById(R.id.btnCalcularArea);
        Button btnCalcularVolumen = findViewById(R.id.btnCalcularVolumen);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnCalcularArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularArea();
            }
        });

        btnCalcularVolumen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularVolumen();
            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularArea() {
        String ladoStr = etLado.getText().toString().trim();

        if (!ladoStr.isEmpty()) {
            double lado = Double.parseDouble(ladoStr);
            double area = 6 * lado * lado;

            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String resultado = "Área del cubo: " + decimalFormat.format(area);

            tvResultado.setText(resultado);
        } else {
            tvResultado.setText("Por favor, introduce el lado del cubo.");
        }
    }

    private void calcularVolumen() {
        String ladoStr = etLado.getText().toString().trim();

        if (!ladoStr.isEmpty()) {
            double lado = Double.parseDouble(ladoStr);
            double volumen = lado * lado * lado;

            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String resultado = "Volumen del cubo: " + decimalFormat.format(volumen);

            tvResultado.setText(resultado);
        } else {
            tvResultado.setText("Por favor, introduce el lado del cubo.");
        }
    }
}
